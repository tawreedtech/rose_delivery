import 'package:sixvalley_delivery_boy/interface/repository_interface.dart';

abstract class OnboardRepositoryInterface implements RepositoryInterface{}